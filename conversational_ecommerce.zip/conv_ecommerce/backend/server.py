from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import json
import logging
import re
import uuid
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone

from catalog import CATALOG
from memory_db import InMemoryDB

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

# In-memory data store — no database server required. Data resets on restart.
db = InMemoryDB()

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

app = FastAPI(title="Conversational eCommerce Search")
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger("conversearch")


# ---------- Models ----------
class Product(BaseModel):
    id: str
    title: str
    brand: str
    category: str
    subcategory: str
    price: int
    mrp: int
    rating: float
    rating_count: int
    tags: List[str]
    features: List[str]
    description: str
    image: str
    stock: int


class SearchRequest(BaseModel):
    query: str
    session_id: Optional[str] = None


class ProductMatch(BaseModel):
    product: Product
    reason: str
    score: float


class SearchResponse(BaseModel):
    session_id: str
    query: str
    summary: str
    intent: Dict[str, Any]
    results: List[ProductMatch]


class CartItem(BaseModel):
    product_id: str
    quantity: int = 1


class CartAction(BaseModel):
    session_id: str
    product_id: str
    quantity: int = 1


class WishlistAction(BaseModel):
    session_id: str
    product_id: str


class CheckoutRequest(BaseModel):
    session_id: str
    name: str
    address: str
    payment_method: str = "cod"


# ---------- Helpers ----------
def product_dict(p: Product) -> dict:
    return p.model_dump() if hasattr(p, "model_dump") else p.dict()


def _extract_json(text: str) -> Optional[dict]:
    if not text:
        return None
    # try direct
    try:
        return json.loads(text)
    except Exception:
        pass
    # find first {...}
    m = re.search(r"\{[\s\S]*\}", text)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            return None
    return None


async def _call_llm(system_prompt: str, user_text: str) -> str:
    """Call the OpenAI Chat Completions API directly (replaces Emergent's LlmChat wrapper)."""
    from openai import AsyncOpenAI

    client_llm = AsyncOpenAI(api_key=OPENAI_API_KEY)
    resp = await client_llm.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_text},
        ],
        temperature=0.3,
    )
    return resp.choices[0].message.content or ""


async def _llm_extract_intent(query: str, session_id: str) -> Dict[str, Any]:
    """Use LLM to extract structured intent from a natural-language query."""
    if not OPENAI_API_KEY:
        return {"keywords": [query], "category": None, "min_price": None, "max_price": None, "audience": None, "features": []}

    system_prompt = (
        "You are a shopping assistant that converts a shopper's natural-language query into a strict JSON filter. "
        "Return ONLY a JSON object with the keys: "
        "keywords (array of strings, key search terms), "
        "category (string or null, e.g. 'Footwear', 'Electronics', 'Apparel', 'Home & Kitchen', 'Sports', 'Beauty', 'Books', 'Toys', 'Health', 'Accessories'), "
        "subcategory (string or null, e.g. 'Running Shoes', 'Headphones'), "
        "min_price (integer INR or null), "
        "max_price (integer INR or null), "
        "audience (string or null, e.g. 'beginner', 'men', 'women', 'kids', 'gift'), "
        "brand (string or null), "
        "features (array of strings, desired attributes e.g. 'cushioned', 'noise-cancelling', 'wireless'). "
        "Interpret currency in Indian Rupees. Do NOT include any prose."
    )
    try:
        resp = await _call_llm(system_prompt, query)
        data = _extract_json(resp)
        if not data:
            data = {}
        # sanitize
        return {
            "keywords": data.get("keywords") or [],
            "category": data.get("category"),
            "subcategory": data.get("subcategory"),
            "min_price": data.get("min_price"),
            "max_price": data.get("max_price"),
            "audience": data.get("audience"),
            "brand": data.get("brand"),
            "features": data.get("features") or [],
        }
    except Exception as e:
        logger.exception("LLM intent extraction failed: %s", e)
        return {"keywords": [query], "category": None, "min_price": None, "max_price": None, "audience": None, "features": []}


def _score_product(prod: dict, intent: Dict[str, Any], query: str) -> float:
    score = 0.0
    ql = query.lower()
    title_l = prod["title"].lower()
    desc_l = prod["description"].lower()
    tags_l = [t.lower() for t in prod["tags"]]
    features_l = [f.lower() for f in prod["features"]]
    subcat_l = prod["subcategory"].lower()

    # price
    price = prod["price"]
    if intent.get("max_price") is not None:
        try:
            if price <= int(intent["max_price"]):
                score += 3.0
            else:
                score -= 5.0
        except Exception:
            pass
    if intent.get("min_price") is not None:
        try:
            if price >= int(intent["min_price"]):
                score += 1.0
        except Exception:
            pass

    # category / subcategory (subcategory is a soft boost)
    cat = (intent.get("category") or "").lower()
    subcat = (intent.get("subcategory") or "").lower()
    if cat and cat in prod["category"].lower():
        score += 3.0
    if subcat:
        # Match either direction — LLM might say "Steam Iron" while our subcategory is "Appliances"
        # but the model tag is "iron". Compare against tags/title as well.
        if subcat in subcat_l or subcat_l in subcat:
            score += 4.0
        elif any(subcat in t or t in subcat for t in tags_l):
            score += 3.5
        elif subcat in title_l:
            score += 3.0

    # brand
    brand = (intent.get("brand") or "").lower()
    if brand and brand in prod["brand"].lower():
        score += 3.0

    # audience
    audience = (intent.get("audience") or "").lower()
    if audience:
        blob = " ".join(tags_l) + " " + desc_l + " " + " ".join(features_l)
        if audience in blob:
            score += 2.0

    # features
    for f in intent.get("features") or []:
        fl = str(f).lower()
        if not fl:
            continue
        if any(fl in t or t in fl for t in tags_l):
            score += 1.5
            continue
        if any(fl in feat for feat in features_l):
            score += 1.2
            continue
        if fl in desc_l:
            score += 0.5

    # keywords — bidirectional substring match, and also split into individual tokens
    def kw_tokens(k: str):
        base = [k.lower()]
        for t in re.findall(r"[a-z0-9]+", k.lower()):
            if len(t) >= 3:
                base.append(t)
        return base

    for k in intent.get("keywords") or []:
        for kt in kw_tokens(str(k)):
            if not kt:
                continue
            if kt in title_l:
                score += 2.5
                break
            if any(kt == t or kt in t or t in kt for t in tags_l):
                score += 2.0
                break
            if kt in desc_l:
                score += 0.8
                break

    # raw query token matches (fallback)
    for tok in re.findall(r"[a-z0-9]+", ql):
        if len(tok) < 3:
            continue
        if tok in title_l or any(tok == t for t in tags_l):
            score += 0.5
        elif any(tok in t for t in tags_l):
            score += 0.3

    # rating boost
    score += (prod["rating"] - 4.0) * 0.5

    return score


async def _llm_generate_summary_and_reasons(query: str, intent: Dict[str, Any], top_products: List[dict], session_id: str) -> Dict[str, Any]:
    """Ask LLM for a short summary + a one-line reason for each product."""
    if not OPENAI_API_KEY or not top_products:
        return {
            "summary": f"Here are the best matches for \"{query}\".",
            "reasons": {p["id"]: f"Matches your search for {query}." for p in top_products},
        }

    products_brief = [
        {
            "id": p["id"],
            "title": p["title"],
            "brand": p["brand"],
            "price": p["price"],
            "category": p["subcategory"],
            "tags": p["tags"],
            "features": p["features"],
        }
        for p in top_products
    ]
    system_prompt = (
        "You are a helpful shopping assistant. Given a shopper's query, extracted intent, and a shortlist of candidate products, "
        "return a JSON object with: "
        "summary (one short sentence acknowledging the query and results, max 22 words), "
        "reasons (object mapping product id -> one short sentence, max 20 words, explaining why THIS product matches the query. "
        "Reference concrete facts like price, features, or audience. Do not repeat the product title. Do not use emojis). "
        "Return ONLY valid JSON."
    )
    payload = {"query": query, "intent": intent, "candidates": products_brief}

    try:
        resp = await _call_llm(system_prompt, json.dumps(payload))
        data = _extract_json(resp) or {}
        summary = data.get("summary") or f"Here are the best matches for \"{query}\"."
        reasons = data.get("reasons") or {}
        # fill missing
        for p in top_products:
            reasons.setdefault(p["id"], f"Priced at ₹{p['price']} — a strong match for your query.")
        return {"summary": summary, "reasons": reasons}
    except Exception as e:
        logger.exception("LLM reason generation failed: %s", e)
        return {
            "summary": f"Here are the best matches for \"{query}\".",
            "reasons": {p["id"]: f"Priced at ₹{p['price']} — matches your query." for p in top_products},
        }


# ---------- Startup: seed catalog ----------
@app.on_event("startup")
async def seed_catalog():
    coll = db.products
    count = await coll.count_documents({})
    if count == 0:
        await coll.insert_many([dict(p) for p in CATALOG])
        logger.info("Seeded %d products.", len(CATALOG))
    else:
        # Refresh to always keep in sync
        await coll.delete_many({})
        await coll.insert_many([dict(p) for p in CATALOG])
        logger.info("Refreshed %d products.", len(CATALOG))


# ---------- Routes ----------
@api_router.get("/")
async def root():
    return {"message": "Conversational eCommerce Search API", "products": len(CATALOG)}


@api_router.get("/products", response_model=List[Product])
async def list_products(
    category: Optional[str] = None,
    skip: int = 0,
    limit: int = 40,
):
    q = {}
    if category and category != "All":
        q["category"] = category
    items = await db.products.find(q, {"_id": 0}).skip(skip).limit(limit).to_list(limit)
    return [Product(**it) for it in items]


@api_router.get("/products/count")
async def products_count(category: Optional[str] = None):
    q = {}
    if category and category != "All":
        q["category"] = category
    n = await db.products.count_documents(q)
    return {"count": n}


@api_router.get("/products/{product_id}", response_model=Product)
async def get_product(product_id: str):
    it = await db.products.find_one({"id": product_id}, {"_id": 0})
    if not it:
        raise HTTPException(status_code=404, detail="Product not found")
    return Product(**it)


@api_router.get("/categories")
async def get_categories():
    docs = await db.products.find({}, {"_id": 0, "category": 1}).to_list(1000)
    seen = []
    for d in docs:
        c = d.get("category")
        if c and c not in seen:
            seen.append(c)
    return {"categories": seen}


@api_router.post("/search", response_model=SearchResponse)
async def conversational_search(req: SearchRequest):
    session_id = req.session_id or str(uuid.uuid4())
    query = req.query.strip()
    if not query:
        raise HTTPException(status_code=400, detail="Query cannot be empty")

    # 1. Extract intent
    intent = await _llm_extract_intent(query, session_id)

    # 2. Build a hard prefilter to keep the candidate set small (important at 1000+ SKUs).
    # We only hard-filter on category and price — subcategory and brand are used as scoring
    # boosts because the LLM often emits very specific subcategory names (e.g. "Steam Iron",
    # "Microwave Ovens") that won't match our coarser catalog subcategories.
    mongo_q: Dict[str, Any] = {}
    if intent.get("category"):
        mongo_q["category"] = {"$regex": f"^{re.escape(str(intent['category']))}$", "$options": "i"}
    price_q: Dict[str, Any] = {}
    if intent.get("min_price") is not None:
        try:
            price_q["$gte"] = int(intent["min_price"])
        except Exception:
            pass
    if intent.get("max_price") is not None:
        try:
            price_q["$lte"] = int(intent["max_price"])
        except Exception:
            pass
    if price_q:
        mongo_q["price"] = price_q

    candidates = await db.products.find(mongo_q, {"_id": 0}).to_list(2000)

    # Fallback: if category filter returned nothing (e.g. LLM picked a category we don't have),
    # try again without category so keywords can still drive matches.
    if not candidates and "category" in mongo_q:
        soft_q = {k: v for k, v in mongo_q.items() if k != "category"}
        candidates = await db.products.find(soft_q, {"_id": 0}).to_list(2000)
    if not candidates:
        candidates = await db.products.find({}, {"_id": 0}).to_list(2000)

    # 3. Score
    scored = []
    for p in candidates:
        s = _score_product(p, intent, query)
        if s > 0:
            scored.append((s, p))
    scored.sort(key=lambda x: x[0], reverse=True)

    top = scored[:12] if scored else []
    top_products = [p for _, p in top]

    # 4. Generate summary + reasons
    reason_data = await _llm_generate_summary_and_reasons(query, intent, top_products, session_id)
    summary = reason_data["summary"]
    reasons = reason_data["reasons"]

    results = []
    for s, p in top:
        results.append(
            ProductMatch(
                product=Product(**p),
                reason=reasons.get(p["id"], "Matches your search."),
                score=round(s, 2),
            )
        )

    # log history
    await db.search_history.insert_one(
        {
            "session_id": session_id,
            "query": query,
            "intent": intent,
            "result_ids": [p["id"] for p in top_products],
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
    )

    return SearchResponse(
        session_id=session_id,
        query=query,
        summary=summary,
        intent=intent,
        results=results,
    )


@api_router.get("/search/suggestions")
async def suggestions():
    return {
        "suggestions": [
            "Show me running shoes under ₹5,000 suitable for beginners",
            "Best wireless headphones with long battery life under ₹5,000",
            "Budget 5G smartphone with big battery below ₹15,000",
            "Gift ideas for someone who loves fitness under ₹2,000",
            "Formal shirts for men for the office",
            "Cushioned yoga mat for beginners",
            "Premium noise cancelling headphones for travel",
            "Casual sneakers for men under ₹5,000",
        ]
    }


# ---------- Cart ----------
@api_router.get("/cart/{session_id}")
async def get_cart(session_id: str):
    doc = await db.carts.find_one({"session_id": session_id}, {"_id": 0})
    if not doc:
        return {"session_id": session_id, "items": [], "subtotal": 0, "total_items": 0}
    items = doc.get("items", [])
    out_items = []
    subtotal = 0
    total_qty = 0
    for it in items:
        p = await db.products.find_one({"id": it["product_id"]}, {"_id": 0})
        if not p:
            continue
        line_total = p["price"] * it["quantity"]
        subtotal += line_total
        total_qty += it["quantity"]
        out_items.append(
            {
                "product": p,
                "quantity": it["quantity"],
                "line_total": line_total,
            }
        )
    return {
        "session_id": session_id,
        "items": out_items,
        "subtotal": subtotal,
        "total_items": total_qty,
    }


@api_router.post("/cart/add")
async def add_to_cart(action: CartAction):
    p = await db.products.find_one({"id": action.product_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")
    doc = await db.carts.find_one({"session_id": action.session_id})
    if not doc:
        await db.carts.insert_one(
            {"session_id": action.session_id, "items": [{"product_id": action.product_id, "quantity": action.quantity}]}
        )
    else:
        items = doc.get("items", [])
        found = False
        for it in items:
            if it["product_id"] == action.product_id:
                it["quantity"] += action.quantity
                found = True
                break
        if not found:
            items.append({"product_id": action.product_id, "quantity": action.quantity})
        await db.carts.update_one({"session_id": action.session_id}, {"$set": {"items": items}})
    return await get_cart(action.session_id)


@api_router.post("/cart/update")
async def update_cart(action: CartAction):
    doc = await db.carts.find_one({"session_id": action.session_id})
    if not doc:
        raise HTTPException(status_code=404, detail="Cart not found")
    items = doc.get("items", [])
    new_items = []
    for it in items:
        if it["product_id"] == action.product_id:
            if action.quantity > 0:
                new_items.append({"product_id": action.product_id, "quantity": action.quantity})
            # else drop
        else:
            new_items.append(it)
    await db.carts.update_one({"session_id": action.session_id}, {"$set": {"items": new_items}})
    return await get_cart(action.session_id)


@api_router.post("/cart/remove")
async def remove_from_cart(action: CartAction):
    action.quantity = 0
    return await update_cart(action)


# ---------- Wishlist ----------
@api_router.get("/wishlist/{session_id}")
async def get_wishlist(session_id: str):
    doc = await db.wishlists.find_one({"session_id": session_id}, {"_id": 0})
    if not doc:
        return {"session_id": session_id, "items": []}
    products = []
    for pid in doc.get("product_ids", []):
        p = await db.products.find_one({"id": pid}, {"_id": 0})
        if p:
            products.append(p)
    return {"session_id": session_id, "items": products}


@api_router.post("/wishlist/toggle")
async def toggle_wishlist(action: WishlistAction):
    p = await db.products.find_one({"id": action.product_id}, {"_id": 0})
    if not p:
        raise HTTPException(status_code=404, detail="Product not found")
    doc = await db.wishlists.find_one({"session_id": action.session_id})
    if not doc:
        await db.wishlists.insert_one({"session_id": action.session_id, "product_ids": [action.product_id]})
        return {"added": True, "product_id": action.product_id}
    pids = doc.get("product_ids", [])
    if action.product_id in pids:
        pids = [x for x in pids if x != action.product_id]
        added = False
    else:
        pids.append(action.product_id)
        added = True
    await db.wishlists.update_one({"session_id": action.session_id}, {"$set": {"product_ids": pids}})
    return {"added": added, "product_id": action.product_id}


# ---------- Checkout (mocked) ----------
@api_router.post("/checkout")
async def checkout(req: CheckoutRequest):
    cart = await get_cart(req.session_id)
    if not cart["items"]:
        raise HTTPException(status_code=400, detail="Cart is empty")
    order_id = "ORD" + uuid.uuid4().hex[:8].upper()
    order = {
        "order_id": order_id,
        "session_id": req.session_id,
        "name": req.name,
        "address": req.address,
        "payment_method": req.payment_method,
        "items": cart["items"],
        "subtotal": cart["subtotal"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status": "confirmed",
    }
    await db.orders.insert_one(order)
    await db.carts.update_one({"session_id": req.session_id}, {"$set": {"items": []}})
    return {"order_id": order_id, "status": "confirmed", "subtotal": cart["subtotal"], "items_count": cart["total_items"]}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
