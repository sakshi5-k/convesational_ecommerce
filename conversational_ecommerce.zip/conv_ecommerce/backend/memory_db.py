"""
Drop-in, dependency-free replacement for the Motor/MongoDB client used by
server.py. Everything lives in a plain Python list in process memory — no
database server needed. Data resets whenever the backend restarts.

Only supports the exact query/update shapes server.py actually uses:
  - equality matches, $regex/$options, $gte/$lte
  - projections of the form {"_id": 0} or {"_id": 0, "field": 1}
  - $set updates
  - find / find_one / count_documents / insert_one / insert_many /
    delete_many / update_one
"""

import copy
import re
from types import SimpleNamespace
from typing import Any, Dict, List, Optional


def _match(doc: Dict[str, Any], query: Optional[Dict[str, Any]]) -> bool:
    if not query:
        return True
    for key, cond in query.items():
        val = doc.get(key)
        if isinstance(cond, dict):
            for op, opval in cond.items():
                if op == "$regex":
                    flags = re.IGNORECASE if "i" in cond.get("$options", "") else 0
                    if val is None or not re.search(opval, str(val), flags):
                        return False
                elif op == "$options":
                    continue
                elif op == "$gte":
                    if val is None or not (val >= opval):
                        return False
                elif op == "$lte":
                    if val is None or not (val <= opval):
                        return False
                elif op == "$in":
                    if val not in opval:
                        return False
        else:
            if val != cond:
                return False
    return True


def _project(doc: Dict[str, Any], projection: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not projection:
        return copy.deepcopy(doc)
    include_fields = [f for f, v in projection.items() if f != "_id" and v == 1]
    if include_fields:
        out = {f: doc.get(f) for f in include_fields}
    else:
        out = copy.deepcopy(doc)
        out.pop("_id", None)
    return copy.deepcopy(out)


class Cursor:
    def __init__(self, docs: List[Dict[str, Any]]):
        self._docs = docs
        self._skip_n = 0
        self._limit_n: Optional[int] = None

    def skip(self, n: int) -> "Cursor":
        self._skip_n = n
        return self

    def limit(self, n: int) -> "Cursor":
        self._limit_n = n
        return self

    async def to_list(self, length: Optional[int] = None) -> List[Dict[str, Any]]:
        data = self._docs[self._skip_n:]
        cap = self._limit_n if self._limit_n is not None else length
        if cap is not None:
            data = data[:cap]
        return data


class Collection:
    def __init__(self):
        self._docs: List[Dict[str, Any]] = []

    def find(self, query: Optional[Dict[str, Any]] = None, projection: Optional[Dict[str, Any]] = None) -> Cursor:
        matched = [_project(d, projection) for d in self._docs if _match(d, query)]
        return Cursor(matched)

    async def find_one(self, query: Optional[Dict[str, Any]] = None, projection: Optional[Dict[str, Any]] = None):
        for d in self._docs:
            if _match(d, query):
                return _project(d, projection)
        return None

    async def count_documents(self, query: Optional[Dict[str, Any]] = None) -> int:
        return sum(1 for d in self._docs if _match(d, query))

    async def insert_one(self, doc: Dict[str, Any]):
        self._docs.append(copy.deepcopy(doc))
        return SimpleNamespace(inserted_id=doc.get("id"))

    async def insert_many(self, docs: List[Dict[str, Any]]):
        self._docs.extend(copy.deepcopy(d) for d in docs)
        return SimpleNamespace(inserted_ids=[d.get("id") for d in docs])

    async def delete_many(self, query: Optional[Dict[str, Any]] = None):
        if not query:
            n = len(self._docs)
            self._docs.clear()
            return SimpleNamespace(deleted_count=n)
        keep = [d for d in self._docs if not _match(d, query)]
        n = len(self._docs) - len(keep)
        self._docs[:] = keep
        return SimpleNamespace(deleted_count=n)

    async def update_one(self, query: Dict[str, Any], update: Dict[str, Any]):
        for d in self._docs:
            if _match(d, query):
                if "$set" in update:
                    d.update(update["$set"])
                return SimpleNamespace(matched_count=1, modified_count=1)
        return SimpleNamespace(matched_count=0, modified_count=0)


class InMemoryDB:
    """Mimics `client[db_name]` attribute-style collection access."""

    def __init__(self):
        self._collections: Dict[str, Collection] = {}

    def __getattr__(self, name: str) -> Collection:
        if name not in self._collections:
            self._collections[name] = Collection()
        return self._collections[name]
