"""Backend API tests for Conversational eCommerce Search.

Covers:
  * Health & catalog endpoints
  * Model-specific search relevance (Slippers, Oven, Iron, Refrigerator,
    Washing Machine, Kettle, Yoga Mat, Dumbbell, Trimmer, Running Shoes)
  * Cart CRUD, wishlist toggle, checkout
"""
import os
import uuid
import pytest
import requests

BASE_URL = os.environ["EXPO_PUBLIC_BACKEND_URL"].rstrip("/")
API = f"{BASE_URL}/api"

EXPECTED_PRODUCT_COUNT = 1860


@pytest.fixture(scope="session")
def s():
    sess = requests.Session()
    sess.headers.update({"Content-Type": "application/json"})
    return sess


@pytest.fixture(scope="session")
def sid():
    return f"TEST_{uuid.uuid4().hex[:8]}"


def _search(s, query, timeout=120):
    r = s.post(f"{API}/search", json={"query": query}, timeout=timeout)
    assert r.status_code == 200, f"search failed: {r.status_code} {r.text[:200]}"
    return r.json()


def _titles(d, n=5):
    return [x["product"]["title"] for x in d["results"][:n]]


def _subcats(d, n=5):
    return [x["product"]["subcategory"] for x in d["results"][:n]]


# ---------------- Health & catalog ----------------
def test_root(s):
    r = s.get(f"{API}/")
    assert r.status_code == 200
    d = r.json()
    assert d.get("products") == EXPECTED_PRODUCT_COUNT
    assert "message" in d


def test_products_count(s):
    r = s.get(f"{API}/products/count")
    assert r.status_code == 200
    assert r.json()["count"] == EXPECTED_PRODUCT_COUNT


def test_products_list(s):
    r = s.get(f"{API}/products?limit=50")
    assert r.status_code == 200
    prods = r.json()
    assert isinstance(prods, list) and len(prods) == 50
    assert all("id" in p and "price" in p and "image" in p for p in prods)


def test_product_detail(s):
    r = s.get(f"{API}/products/p001")
    assert r.status_code == 200
    d = r.json()
    assert d["id"] == "p001"


def test_product_detail_404(s):
    r = s.get(f"{API}/products/nonexistent_xxx")
    assert r.status_code == 404


def test_categories(s):
    r = s.get(f"{API}/categories")
    assert r.status_code == 200
    cats = r.json()["categories"]
    for c in ["Footwear", "Electronics", "Home & Kitchen", "Sports", "Beauty"]:
        assert c in cats, f"missing category: {c}"


def test_suggestions(s):
    r = s.get(f"{API}/search/suggestions")
    assert r.status_code == 200
    assert len(r.json()["suggestions"]) == 8


# ---------------- Model-specific search relevance ----------------
def test_search_slippers(s):
    """User bug: entering 'slippers' should return slippers, NOT shoes/sneakers."""
    d = _search(s, "comfortable slippers for home")
    top_titles = _titles(d)
    top_subcats = _subcats(d)
    # Every top-5 result must be a Slippers subcategory item
    assert all(sc == "Slippers" for sc in top_subcats), (
        f"Non-Slippers items in top-5: {list(zip(top_titles, top_subcats))}"
    )
    # No shoe/sneaker/sandal titles should appear in top-5
    banned = ("shoe", "sneaker", "sandal", "boot")
    for t in top_titles:
        tl = t.lower()
        assert not any(b in tl for b in banned), f"Banned footwear type in top-5: {t}"


def test_search_microwave_oven(s):
    d = _search(s, "microwave oven for cooking")
    top_titles = _titles(d)
    # All top-5 must have 'Microwave Oven' in title
    assert all("microwave oven" in t.lower() for t in top_titles), (
        f"Non-Microwave-Oven items in top-5: {top_titles}"
    )
    # No cookware bleed
    banned = ("tawa", "frying pan", "kadai", "saucepan")
    for t in top_titles:
        tl = t.lower()
        assert not any(b in tl for b in banned), f"Cookware bleed: {t}"


def test_search_steam_iron(s):
    d = _search(s, "steam iron for clothes")
    top_titles = _titles(d)
    # All top-5 must be Iron items (title contains 'Iron', not 'Ironbox' etc.)
    assert all("iron" in t.lower() for t in top_titles), f"Non-Iron in top-5: {top_titles}"
    # And they should not be bedding / comforter
    banned = ("comforter", "bedsheet", "pillow", "blanket", "quilt")
    for t in top_titles:
        tl = t.lower()
        assert not any(b in tl for b in banned), f"Bedding bleed: {t}"


def test_search_refrigerator_under_40k(s):
    d = _search(s, "refrigerator with big freezer under 40000")
    top = d["results"][:5]
    assert len(top) >= 1
    for item in top:
        title = item["product"]["title"].lower()
        price = item["product"]["price"]
        assert "refrigerator" in title, f"Non-refrigerator in top-5: {item['product']['title']}"
        assert price <= 40000, f"Over-budget: {item['product']['title']} at ₹{price}"


def test_search_washing_machine(s):
    d = _search(s, "washing machine")
    top_titles = _titles(d)
    assert all("washing machine" in t.lower() for t in top_titles), (
        f"Non-Washing-Machine in top-5: {top_titles}"
    )


def test_search_kettle(s):
    d = _search(s, "kettle")
    top_titles = _titles(d)
    assert all("kettle" in t.lower() for t in top_titles), f"Non-Kettle in top-5: {top_titles}"


def test_search_yoga_mat(s):
    d = _search(s, "yoga mat")
    top_titles = _titles(d)
    assert all("yoga mat" in t.lower() for t in top_titles), f"Non-Yoga-Mat in top-5: {top_titles}"
    banned = ("dumbbell", "skipping rope", "kettlebell")
    for t in top_titles:
        tl = t.lower()
        assert not any(b in tl for b in banned), f"Fitness bleed: {t}"


def test_search_dumbbells(s):
    d = _search(s, "dumbbells for home gym")
    top_titles = _titles(d)
    assert all("dumbbell" in t.lower() for t in top_titles), f"Non-Dumbbell in top-5: {top_titles}"


def test_search_trimmer(s):
    d = _search(s, "trimmer for men")
    top_titles = _titles(d)
    assert all("trimmer" in t.lower() for t in top_titles), f"Non-Trimmer in top-5: {top_titles}"
    banned = ("shaver", "hair dryer", "epilator", "straightener")
    for t in top_titles:
        tl = t.lower()
        assert not any(b in tl for b in banned), f"Personal-care bleed: {t}"


def test_search_running_shoes_regression(s):
    """Previously-passing sanity search — must still work."""
    d = _search(s, "Show me running shoes under ₹5,000 suitable for beginners")
    top = d["results"][:5]
    assert len(top) >= 1
    for item in top:
        p = item["product"]
        assert p["category"] == "Footwear", f"non-Footwear: {p['title']}"
        assert p["price"] <= 5000, f"over-budget: {p['title']} at {p['price']}"
        # title should mention Shoes / Sneakers / Runner-ish
        tl = p["title"].lower()
        assert any(k in tl for k in ("shoe", "sneaker", "runner")), f"non-shoe: {p['title']}"


def test_search_empty(s):
    r = s.post(f"{API}/search", json={"query": ""})
    assert r.status_code == 400


# ---------------- Cart CRUD ----------------
def test_cart_flow(s, sid):
    r = s.post(f"{API}/cart/add", json={"session_id": sid, "product_id": "p001", "quantity": 1})
    assert r.status_code == 200
    assert r.json()["total_items"] == 1

    r = s.get(f"{API}/cart/{sid}")
    assert r.status_code == 200
    assert r.json()["total_items"] == 1

    s.post(f"{API}/cart/add", json={"session_id": sid, "product_id": "p011", "quantity": 2})
    r = s.get(f"{API}/cart/{sid}")
    assert r.json()["total_items"] == 3

    r = s.post(f"{API}/cart/update", json={"session_id": sid, "product_id": "p001", "quantity": 3})
    assert r.status_code == 200
    items = {i["product"]["id"]: i["quantity"] for i in r.json()["items"]}
    assert items["p001"] == 3

    r = s.post(f"{API}/cart/remove", json={"session_id": sid, "product_id": "p001", "quantity": 0})
    assert r.status_code == 200
    ids = [i["product"]["id"] for i in r.json()["items"]]
    assert "p001" not in ids


def test_cart_add_invalid_product(s, sid):
    r = s.post(f"{API}/cart/add", json={"session_id": sid, "product_id": "invalid_xxx", "quantity": 1})
    assert r.status_code == 404


# ---------------- Wishlist ----------------
def test_wishlist_toggle(s):
    wsid = f"TEST_wl_{uuid.uuid4().hex[:6]}"
    r = s.post(f"{API}/wishlist/toggle", json={"session_id": wsid, "product_id": "p001"})
    assert r.status_code == 200 and r.json()["added"] is True

    r = s.get(f"{API}/wishlist/{wsid}")
    assert r.status_code == 200
    assert any(p["id"] == "p001" for p in r.json()["items"])

    r = s.post(f"{API}/wishlist/toggle", json={"session_id": wsid, "product_id": "p001"})
    assert r.json()["added"] is False


# ---------------- Checkout (mocked) ----------------
def test_checkout_flow(s):
    csid = f"TEST_ck_{uuid.uuid4().hex[:6]}"
    s.post(f"{API}/cart/add", json={"session_id": csid, "product_id": "p001", "quantity": 1})
    r = s.post(f"{API}/checkout", json={"session_id": csid, "name": "Test User", "address": "123 Test Rd"})
    assert r.status_code == 200
    d = r.json()
    assert d["order_id"].startswith("ORD")
    assert d["status"] == "confirmed"
    r = s.get(f"{API}/cart/{csid}")
    assert r.json()["total_items"] == 0


def test_checkout_empty_cart(s):
    esid = f"TEST_empty_{uuid.uuid4().hex[:6]}"
    r = s.post(f"{API}/checkout", json={"session_id": esid, "name": "X", "address": "Y"})
    assert r.status_code == 400
