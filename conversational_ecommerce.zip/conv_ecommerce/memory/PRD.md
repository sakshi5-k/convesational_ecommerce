# Conversational eCommerce Search — Product Requirements

## Overview
A mobile eCommerce app (Amazon/Flipkart-style) with a **conversational AI search** as the hero feature. Users type natural-language queries in ₹ (INR) and the app understands intent, filters a seeded catalog, and explains why each product matches.

## Core Features
- **Conversational Search** — Natural-language input; LLM extracts structured intent (category, subcategory, min/max price, brand, audience, features). Backend deterministic scoring ranks 40-product catalog. LLM writes a session summary + per-product "why this matches" reason.
- **Product Grid & Browse** — Home doubles as browse view (category chips) when no query is active.
- **Product Detail** — Hero image, features, description, tags, sticky Add-to-Cart.
- **Wishlist** — Toggle from cards/detail; dedicated tab with badge.
- **Cart** — Quantity +/-, remove, live subtotal, badge on tab.
- **Checkout (mocked)** — Address + payment method selector (COD / UPI / Card) → mock confirmation with order id.

## Tech Stack
- **Frontend:** Expo SDK 54, expo-router, expo-image, expo-linear-gradient, react-native-safe-area-context, AsyncStorage
- **Backend:** FastAPI + Motor (MongoDB async), pydantic v2
- **AI:** `emergentintegrations` — openai `gpt-5.4-mini` via **Emergent LLM Key** (2 calls per search: intent JSON + summary/reasons JSON)
- **Session:** client-generated ID persisted in AsyncStorage; used for cart, wishlist, search history

## API Surface (/api prefix)
- `GET /` — health + product count
- `GET /products?category=&limit=` and `GET /products/{id}`
- `GET /categories`, `GET /search/suggestions`
- `POST /search` `{ query, session_id? }` → `{ session_id, summary, intent, results:[{product,reason,score}] }`
- `GET /cart/{sid}`, `POST /cart/add`, `POST /cart/update`, `POST /cart/remove`
- `GET /wishlist/{sid}`, `POST /wishlist/toggle`
- `POST /checkout` (mocked)

## Design
iOS-Native Clean personality (Moss/Sage green brand `#768A44`, cream surface `#FDFDF9`, coral secondary `#C15B3D`). System font. Bottom tabs: Search / Wishlist / Cart with badges.

## Seeded Catalog
40 products across Footwear, Electronics (Smartphones/Headphones/Laptops/Smartwatches/Gaming), Apparel (Men/Women), Home & Kitchen, Sports, Beauty, Books, Toys, Health, Accessories — all with realistic INR pricing.

## Testing
- Backend: 15/15 pytest cases green (`/app/test_reports/pytest/results.xml`)
- Frontend: manually verified home → search → why-this sheet → detail → add-to-cart

## Deliverable
Source zip at `/app/conversational_ecommerce_source.zip` for download.
