# Running this project locally (VS Code)

This app was originally built on the **Emergent** platform (emergent.sh), so it shipped
wired up to Emergent-only infrastructure. Here's what was changed to make it run
anywhere, with no external database:

## What changed
1. **`backend/server.py`** — replaced the two `emergentintegrations.llm.chat.LlmChat`
   calls (Emergent-only package + key) with a small `_call_llm()` helper that uses the
   standard `openai` Python SDK directly.
2. **`backend/memory_db.py`** (new) — a tiny in-memory database that swaps in for
   MongoDB/Motor. It supports the exact handful of query shapes this app uses (equality
   matches, price ranges, category regex, `$set` updates). No database server to
   install — data just lives in the running Python process and resets when you restart
   the backend.
3. **`backend/requirements.txt`** — removed `emergentintegrations`, `pymongo`, and
   `motor`; added `openai`.
4. **`backend/.env`** — removed `MONGO_URL`/`DB_NAME`; added `OPENAI_API_KEY` +
   `OPENAI_MODEL` (defaults to `gpt-4o-mini`).
5. **`frontend/.env`** — points `EXPO_PUBLIC_BACKEND_URL` at `http://localhost:8000`
   instead of Emergent's preview tunnel URL.
6. Added a `if __name__ == "__main__"` block to `server.py` so it can also be run
   directly with `python server.py`, in addition to `uvicorn`.

**Note on data persistence:** since there's no database, the product catalog (1,860
items) is reseeded on every backend restart, and any carts/wishlists/orders created
during a session are lost when the backend restarts. If you later want data to survive
restarts, the cleanest option is SQLite (a single local file, no server to run) — say
the word and I'll wire that in instead.

**Note on AI search:** the natural-language intent parsing + "why this matches" reasons
are optional. If `OPENAI_API_KEY` is left blank, the app still runs — it just falls back
to plain keyword search. To get the full AI experience, add your own OpenAI API key
(paid, pay-as-you-go — get one at platform.openai.com) to `backend/.env`. If you'd
rather use Claude/Anthropic instead, say so and I can swap `_call_llm()` over.

## Prerequisites
- Python 3.10+
- Node.js 18+ and Yarn (`npm install -g yarn` if you don't have it)
- Expo Go app on your phone (optional, for testing on a real device) — or just use the
  web/simulator target

## 1. Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python server.py                # or: uvicorn server:app --reload
```

The API will be at `http://localhost:8000` — check `http://localhost:8000/api/` for a
health response.

## 2. Frontend

```bash
cd frontend
yarn install
yarn start
```

This opens the Expo dev tools. Press `w` for web, or scan the QR code with Expo Go on
your phone.

**If you're testing on a physical phone**, `localhost` in `frontend/.env` won't reach
your laptop — edit `EXPO_PUBLIC_BACKEND_URL` to your machine's LAN IP instead, e.g.
`http://192.168.1.5:8000` (find it with `ipconfig` on Windows or `ifconfig`/`ip addr` on
Mac/Linux), and make sure your phone is on the same Wi-Fi network.

## Notes
- `frontend/scripts/cmd-guard.js` (run via the `preinstall` script in `package.json`) is
  an Emergent sandbox guardrail that blocks a few disallowed install commands. It's
  self-contained and shouldn't block a normal `yarn install` of this project's existing
  dependencies — but if it ever complains, you can safely delete the `"preinstall"` line
  from `frontend/package.json`.
