# Conversational Search for an eCommerce Application

A mobile eCommerce app where the primary way to shop is by typing a natural-language
query — e.g. *"Show me running shoes under ₹5,000 suitable for beginners"* — and getting
back a ranked set of matching products, each with a plain-English explanation of why it
was picked.

## Demo query
```
Show me running shoes under ₹5,000 suitable for beginners
```
→ the app parses this into structured intent (category: Footwear, subcategory: Running
Shoes, max_price: 5000, audience: beginner), scores the 40-item catalog against it, and
returns the top matches with a "Why this matches" reason for each.

---

## Architecture

```
frontend/   Expo (React Native) app — search UI, product grid, detail, cart, wishlist, checkout
backend/    FastAPI service — NL → intent extraction, scoring/ranking, cart/wishlist/checkout APIs
```

- **Frontend:** React Native via Expo (SDK 54) + expo-router (file-based navigation).
- **Backend:** Python FastAPI, single `/api` router.
- **AI:** OpenAI Chat Completions API (`gpt-4o-mini` by default, configurable), called
  twice per search:
  1. **Intent extraction** — turns the free-text query into a strict JSON filter
     (category, subcategory, price range, brand, audience, desired features).
  2. **Summary + reasons** — once candidates are scored, the LLM writes a one-line
     session summary and a short "why this matches" sentence per product.
- **Ranking:** deterministic, not left to the LLM — a scoring function
  (`backend/server.py::_score_product`) weights price fit, category/subcategory match,
  brand, audience, feature and keyword overlap. This keeps results reproducible and
  fast, and means the app degrades gracefully (see below) instead of failing if the LLM
  call errors out.
- **Data store:** in-memory (`backend/memory_db.py`), seeded from `backend/catalog.py`
  (40 hand-written products across Footwear, Electronics, Apparel, Home & Kitchen,
  Sports, Beauty, Books, Toys, Health, Accessories, all with realistic INR pricing).
  No database server to install; data resets when the backend restarts.
- **Graceful fallback:** if `OPENAI_API_KEY` is left blank, the backend skips the LLM
  calls and falls back to plain keyword/category matching so the app still runs and
  returns results — it just loses the natural-language understanding and the generated
  "why" explanations.

### Request flow
```
User types query
  → POST /api/search { query, session_id }
  → LLM #1: query → structured intent JSON
  → score every product in the catalog against that intent
  → take top N candidates
  → LLM #2: candidates + intent → summary + per-product reason
  → response: { summary, intent, results: [{ product, reason, score }] }
  → frontend renders product cards + a "Why this matches" bottom sheet per card
```

### Other features (beyond the core search)
- Product detail screen (hero image, features, description, tags, sticky Add to Cart)
- Wishlist (toggle from card or detail; dedicated tab with badge)
- Cart (quantity controls, remove, live subtotal, badge on tab)
- Mocked checkout (address + COD/UPI/Card selector → order confirmation)
- Category-chip browse view on the home screen when there's no active search

---

## Third-party libraries / AI services used

**AI service**
- [OpenAI API](https://platform.openai.com/) (`openai` Python SDK) — natural-language
  intent parsing and result-explanation generation. Model is configurable via
  `backend/.env` (`OPENAI_MODEL`, defaults to `gpt-4o-mini`).

**Backend (Python)**
- `fastapi`, `uvicorn` — API framework/server
- `pydantic` — request/response schemas and validation
- `python-dotenv` — loads `backend/.env`
- `openai` — LLM calls
- (see `backend/requirements.txt` for exact versions)

**Frontend (React Native / Expo)**
- `expo` (SDK 54) + `expo-router` — app shell and file-based navigation
- `expo-image`, `expo-linear-gradient`, `expo-blur`, `expo-haptics`, `expo-symbols` — UI/UX
- `@expo/vector-icons` — iconography
- `@react-native-async-storage/async-storage` — persisting the client session id locally
- `react-native-gesture-handler`, `react-native-reanimated`, `react-native-worklets`,
  `react-native-screens`, `react-native-safe-area-context` — navigation/animation runtime
- `react-native-webview`, `expo-web-browser`, `expo-linking` — misc Expo scaffolding
- `date-fns`, `dayjs` — date formatting (order timestamps)
- (see `frontend/package.json` for the full list and exact versions)

No paid/proprietary UI kits are used; styling is hand-rolled (`frontend/src/theme.ts`).

---

## Setup instructions

### Prerequisites
- Python 3.10+
- Node.js 18+ and Yarn (`npm install -g yarn`)
- An OpenAI API key (optional — the app runs without one, see "Graceful fallback" above)
- Expo Go app on your phone (optional — for testing on a physical device)

### 1. Backend
```bash
cd backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
Add your OpenAI key to `backend/.env`:
```
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o-mini
```
Then run:
```bash
python server.py                # or: uvicorn server:app --reload
```
API health check: `http://localhost:8000/api/`

### 2. Frontend
```bash
cd frontend
yarn install
yarn start
```
Press `w` for web, or scan the QR code with Expo Go on your phone.

If testing on a **physical phone**, `localhost` in `frontend/.env` won't reach your
laptop — set `EXPO_PUBLIC_BACKEND_URL` to your machine's LAN IP instead (e.g.
`http://192.168.1.5:8000`), found via `ipconfig` / `ifconfig`, with the phone on the same
Wi-Fi network.

### Notes
- The product catalog (40 items) reseeds on every backend restart; there's no database
  server to install. Carts/wishlists/orders created during a session are lost on
  backend restart.
- `frontend/scripts/cmd-guard.js` is a leftover guardrail from the platform this project
  was originally scaffolded on (Emergent) — it's inert for a normal `yarn install` and
  can be deleted from `frontend/package.json`'s `"preinstall"` script if it ever
  complains.
- Full API surface, data model, and design notes: see `memory/PRD.md`.

## API reference
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/` | Health check + product count |
| GET | `/api/products?category=&limit=` | Browse/list products |
| GET | `/api/products/{id}` | Product detail |
| GET | `/api/categories` | List categories |
| GET | `/api/search/suggestions` | Example query chips |
| POST | `/api/search` | `{ query, session_id? }` → conversational search |
| GET/POST | `/api/cart/*` | Cart get/add/update/remove |
| GET/POST | `/api/wishlist/*` | Wishlist get/toggle |
| POST | `/api/checkout` | Mocked checkout → order confirmation |
