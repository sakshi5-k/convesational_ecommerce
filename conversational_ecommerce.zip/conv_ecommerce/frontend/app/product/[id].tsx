import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { Image } from "expo-image";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";

import { Colors, Radius, Spacing, formatPrice, discountPercent } from "@/src/theme";
import { Product, useApp } from "@/src/context/AppContext";

export default function ProductDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { api, addToCart, toggleWishlist, isInWishlist } = useApp();

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await api(`/api/products/${id}`);
        if (r.ok) setProduct(await r.json());
      } catch (e) {
        console.log("product detail load error", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [id, api]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 1800);
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator color={Colors.brandPrimary} />
      </SafeAreaView>
    );
  }
  if (!product) {
    return (
      <SafeAreaView style={styles.center}>
        <Text style={styles.errText}>Product not found.</Text>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Text style={styles.backBtnText}>Go back</Text>
        </Pressable>
      </SafeAreaView>
    );
  }

  const off = discountPercent(product.mrp, product.price);
  const wished = isInWishlist(product.id);

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={{ paddingBottom: 140 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.imageWrap}>
          <Image source={{ uri: product.image }} style={styles.heroImage} contentFit="cover" />
          <LinearGradient
            colors={["rgba(0,0,0,0.3)", "transparent"]}
            style={styles.topScrim}
          />
          <SafeAreaView edges={["top"]} style={styles.topBar}>
            <Pressable
              testID="detail-back"
              onPress={() => router.back()}
              style={styles.iconBtn}
            >
              <Ionicons name="chevron-back" size={22} color={Colors.onSurface} />
            </Pressable>
            <Pressable
              testID="detail-wishlist-toggle"
              onPress={async () => {
                const added = await toggleWishlist(product.id);
                showToast(added ? "Added to wishlist" : "Removed from wishlist");
              }}
              style={styles.iconBtn}
            >
              <Ionicons
                name={wished ? "heart" : "heart-outline"}
                size={20}
                color={wished ? Colors.brandSecondary : Colors.onSurface}
              />
            </Pressable>
          </SafeAreaView>
        </View>

        <View style={styles.body}>
          <Text style={styles.brand}>{product.brand}</Text>
          <Text style={styles.title}>{product.title}</Text>

          <View style={styles.ratingRow}>
            <View style={styles.ratingPill}>
              <Text style={styles.ratingText}>{product.rating.toFixed(1)}</Text>
              <Ionicons name="star" size={12} color="#fff" />
            </View>
            <Text style={styles.ratingCount}>
              {product.rating_count.toLocaleString("en-IN")} ratings
            </Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.price}>{formatPrice(product.price)}</Text>
            {product.mrp > product.price && (
              <>
                <Text style={styles.mrp}>{formatPrice(product.mrp)}</Text>
                <Text style={styles.off}>{off}% off</Text>
              </>
            )}
          </View>

          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Ionicons name="sparkles" size={14} color={Colors.brandPrimary} />
              <Text style={styles.sectionLabel}>Key Features</Text>
            </View>
            {product.features.map((f, i) => (
              <View key={i} style={styles.featureRow}>
                <View style={styles.dot} />
                <Text style={styles.featureText}>{f}</Text>
              </View>
            ))}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionLabel}>About this item</Text>
            <Text style={styles.description}>{product.description}</Text>
          </View>

          <View style={styles.tagRow}>
            {product.tags.map((t) => (
              <View key={t} style={styles.tag}>
                <Text style={styles.tagText}>{t}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      <View style={[styles.stickyBar, { paddingBottom: insets.bottom + Spacing.md }]}>
        <View style={{ flex: 1 }}>
          <Text style={styles.stickyLabel}>Total</Text>
          <Text style={styles.stickyPrice}>{formatPrice(product.price)}</Text>
        </View>
        <Pressable
          testID="add-to-cart-button"
          style={styles.addBtn}
          onPress={async () => {
            await addToCart(product.id, 1);
            showToast("Added to cart");
          }}
        >
          <Ionicons name="bag-add-outline" size={18} color="#fff" />
          <Text style={styles.addBtnText}>Add to Cart</Text>
        </Pressable>
      </View>

      {toast && (
        <View style={[styles.toast, { bottom: insets.bottom + 110 }]} pointerEvents="none">
          <Ionicons name="checkmark-circle" size={16} color="#fff" />
          <Text style={styles.toastText}>{toast}</Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.surface },
  center: { flex: 1, alignItems: "center", justifyContent: "center", padding: Spacing.xl, gap: Spacing.md, backgroundColor: Colors.surface },
  errText: { fontSize: 15, color: Colors.onSurface },
  backBtn: { paddingHorizontal: Spacing.lg, paddingVertical: Spacing.sm, backgroundColor: Colors.onSurface, borderRadius: Radius.pill },
  backBtnText: { color: "#fff", fontWeight: "700" },

  imageWrap: { width: "100%", aspectRatio: 1, backgroundColor: Colors.surfaceTertiary, position: "relative" },
  heroImage: { width: "100%", height: "100%" },
  topScrim: { position: "absolute", top: 0, left: 0, right: 0, height: 100 },
  topBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(255,255,255,0.95)",
    alignItems: "center",
    justifyContent: "center",
  },

  body: { padding: Spacing.lg },
  brand: {
    fontSize: 11,
    color: Colors.muted,
    textTransform: "uppercase",
    letterSpacing: 0.5,
    fontWeight: "700",
  },
  title: { fontSize: 20, fontWeight: "800", color: Colors.onSurface, marginTop: 4, lineHeight: 26 },

  ratingRow: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: Spacing.sm },
  ratingPill: {
    backgroundColor: Colors.success,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: Radius.sm,
    flexDirection: "row",
    alignItems: "center",
    gap: 3,
  },
  ratingText: { color: "#fff", fontSize: 11, fontWeight: "700" },
  ratingCount: { fontSize: 12, color: Colors.muted },

  priceRow: { flexDirection: "row", alignItems: "baseline", gap: 10, marginTop: Spacing.md },
  price: { fontSize: 24, fontWeight: "800", color: Colors.onSurface },
  mrp: { fontSize: 14, color: Colors.muted, textDecorationLine: "line-through" },
  off: { fontSize: 13, color: Colors.brandSecondary, fontWeight: "700" },

  section: { marginTop: Spacing.xl },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: Spacing.sm },
  sectionLabel: {
    fontSize: 12,
    fontWeight: "800",
    color: Colors.onSurface,
    textTransform: "uppercase",
    letterSpacing: 0.6,
  },
  featureRow: { flexDirection: "row", alignItems: "flex-start", gap: Spacing.sm, paddingVertical: 4 },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: Colors.brandPrimary,
    marginTop: 7,
  },
  featureText: { flex: 1, fontSize: 14, color: Colors.onSurface, lineHeight: 20 },
  description: { fontSize: 14, color: Colors.onSurface, lineHeight: 21, marginTop: 4 },

  tagRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: Spacing.xl },
  tag: {
    backgroundColor: Colors.surfaceTertiary,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: Radius.pill,
  },
  tagText: { fontSize: 11, color: Colors.onSurface, fontWeight: "500" },

  stickyBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.surfaceSecondary,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    padding: Spacing.lg,
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.md,
  },
  stickyLabel: { fontSize: 11, color: Colors.muted, fontWeight: "600" },
  stickyPrice: { fontSize: 18, fontWeight: "800", color: Colors.onSurface },
  addBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    backgroundColor: Colors.onSurface,
    paddingHorizontal: Spacing.xl,
    paddingVertical: 14,
    borderRadius: Radius.pill,
  },
  addBtnText: { color: "#fff", fontWeight: "800", fontSize: 14 },

  toast: {
    position: "absolute",
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: Colors.onSurface,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.pill,
  },
  toastText: { color: "#fff", fontSize: 13, fontWeight: "600" },
});
