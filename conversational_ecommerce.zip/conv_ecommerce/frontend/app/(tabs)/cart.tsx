import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { Colors, Radius, Spacing, formatPrice } from "@/src/theme";
import { useApp } from "@/src/context/AppContext";

export default function CartScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { cart, updateCart, removeFromCart } = useApp();

  const items = cart?.items ?? [];

  return (
    <SafeAreaView edges={["top"]} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Cart</Text>
        <Text style={styles.subtitle}>
          {items.length} product{items.length === 1 ? "" : "s"}
        </Text>
      </View>

      {items.length === 0 ? (
        <View style={styles.empty}>
          <Ionicons name="bag-handle-outline" size={56} color={Colors.muted} />
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptyText}>Search or browse to add items.</Text>
          <Pressable
            testID="cart-start-shopping"
            style={styles.shopButton}
            onPress={() => router.replace("/(tabs)")}
          >
            <Text style={styles.shopButtonText}>Start shopping</Text>
          </Pressable>
        </View>
      ) : (
        <>
          <ScrollView
            contentContainerStyle={{ padding: Spacing.lg, paddingBottom: 220 }}
            showsVerticalScrollIndicator={false}
          >
            {items.map((line) => (
              <View key={line.product.id} style={styles.line} testID={`cart-line-${line.product.id}`}>
                <Image source={{ uri: line.product.image }} style={styles.image} contentFit="cover" />
                <View style={styles.info}>
                  <Text style={styles.brand}>{line.product.brand}</Text>
                  <Text style={styles.name} numberOfLines={2}>{line.product.title}</Text>
                  <Text style={styles.price}>{formatPrice(line.line_total)}</Text>
                  <View style={styles.qtyRow}>
                    <View style={styles.qtyControl}>
                      <Pressable
                        testID={`cart-decrease-${line.product.id}`}
                        onPress={() => updateCart(line.product.id, Math.max(0, line.quantity - 1))}
                        style={styles.qtyBtn}
                      >
                        <Ionicons name="remove" size={16} color={Colors.onSurface} />
                      </Pressable>
                      <Text style={styles.qtyText}>{line.quantity}</Text>
                      <Pressable
                        testID={`cart-increase-${line.product.id}`}
                        onPress={() => updateCart(line.product.id, line.quantity + 1)}
                        style={styles.qtyBtn}
                      >
                        <Ionicons name="add" size={16} color={Colors.onSurface} />
                      </Pressable>
                    </View>
                    <Pressable
                      testID={`cart-remove-${line.product.id}`}
                      onPress={() => removeFromCart(line.product.id)}
                      hitSlop={8}
                    >
                      <Text style={styles.removeText}>Remove</Text>
                    </Pressable>
                  </View>
                </View>
              </View>
            ))}
          </ScrollView>

          <View style={[styles.summary, { paddingBottom: insets.bottom + Spacing.lg }]}>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Subtotal</Text>
              <Text style={styles.summaryValue}>{formatPrice(cart?.subtotal ?? 0)}</Text>
            </View>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>Delivery</Text>
              <Text style={styles.summaryValueFree}>FREE</Text>
            </View>
            <View style={[styles.summaryRow, { marginTop: Spacing.sm }]}>
              <Text style={styles.totalLabel}>Total</Text>
              <Text style={styles.totalValue}>{formatPrice(cart?.subtotal ?? 0)}</Text>
            </View>
            <Pressable
              testID="checkout-button"
              style={styles.checkoutBtn}
              onPress={() => router.push("/checkout")}
            >
              <Text style={styles.checkoutText}>Proceed to Checkout</Text>
              <Ionicons name="arrow-forward" size={16} color="#fff" />
            </Pressable>
          </View>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.surface },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: { fontSize: 22, fontWeight: "800", color: Colors.onSurface },
  subtitle: { fontSize: 12, color: Colors.muted, marginTop: 2 },

  empty: { flex: 1, alignItems: "center", justifyContent: "center", padding: Spacing.xl, gap: Spacing.sm },
  emptyTitle: { fontSize: 16, fontWeight: "700", color: Colors.onSurface, marginTop: Spacing.md },
  emptyText: { fontSize: 13, color: Colors.muted },
  shopButton: {
    marginTop: Spacing.lg,
    backgroundColor: Colors.brandPrimary,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.pill,
  },
  shopButtonText: { color: "#fff", fontWeight: "700" },

  line: {
    flexDirection: "row",
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.md,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  image: { width: 88, height: 88, borderRadius: Radius.sm, backgroundColor: Colors.surfaceTertiary },
  info: { flex: 1 },
  brand: { fontSize: 10, textTransform: "uppercase", color: Colors.muted, fontWeight: "700", letterSpacing: 0.5 },
  name: { fontSize: 13, fontWeight: "600", color: Colors.onSurface, marginTop: 2, lineHeight: 17 },
  price: { fontSize: 14, fontWeight: "800", color: Colors.onSurface, marginTop: 6 },
  qtyRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: Spacing.sm },
  qtyControl: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: Radius.pill,
    overflow: "hidden",
  },
  qtyBtn: { paddingHorizontal: 10, paddingVertical: 6 },
  qtyText: { minWidth: 22, textAlign: "center", fontWeight: "700", color: Colors.onSurface },
  removeText: { fontSize: 12, color: Colors.brandSecondary, fontWeight: "700" },

  summary: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.surfaceSecondary,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    padding: Spacing.lg,
  },
  summaryRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingVertical: 3 },
  summaryLabel: { fontSize: 13, color: Colors.muted },
  summaryValue: { fontSize: 13, color: Colors.onSurface, fontWeight: "600" },
  summaryValueFree: { fontSize: 13, color: Colors.success, fontWeight: "700" },
  totalLabel: { fontSize: 15, color: Colors.onSurface, fontWeight: "800" },
  totalValue: { fontSize: 18, color: Colors.onSurface, fontWeight: "800" },
  checkoutBtn: {
    marginTop: Spacing.md,
    backgroundColor: Colors.onSurface,
    padding: Spacing.md,
    borderRadius: Radius.pill,
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
  },
  checkoutText: { color: "#fff", fontSize: 14, fontWeight: "800" },
});
