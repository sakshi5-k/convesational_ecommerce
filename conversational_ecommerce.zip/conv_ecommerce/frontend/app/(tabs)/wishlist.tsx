import React from "react";
import { StyleSheet, Text, View, ScrollView } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import ProductCard from "@/src/components/ProductCard";
import { Colors, Spacing } from "@/src/theme";
import { useApp } from "@/src/context/AppContext";

export default function WishlistScreen() {
  const { wishlist } = useApp();

  return (
    <SafeAreaView edges={["top"]} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Your Wishlist</Text>
        <Text style={styles.subtitle}>{wishlist.length} saved item{wishlist.length === 1 ? "" : "s"}</Text>
      </View>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {wishlist.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons name="heart-outline" size={56} color={Colors.muted} />
            <Text style={styles.emptyTitle}>Save items you love</Text>
            <Text style={styles.emptyText}>Tap the heart icon on any product to save it here.</Text>
          </View>
        ) : (
          <View style={styles.grid}>
            {wishlist.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.surface },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  title: { fontSize: 22, fontWeight: "800", color: Colors.onSurface },
  subtitle: { fontSize: 12, color: Colors.muted, marginTop: 2 },
  scroll: { padding: Spacing.lg, paddingBottom: Spacing.xxxl },
  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  empty: { alignItems: "center", paddingTop: 80, gap: Spacing.sm },
  emptyTitle: { fontSize: 16, fontWeight: "700", color: Colors.onSurface, marginTop: Spacing.md },
  emptyText: { fontSize: 13, color: Colors.muted, textAlign: "center", paddingHorizontal: 40 },
});
