import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";

import ProductCard from "@/src/components/ProductCard";
import { Colors, Radius, Spacing } from "@/src/theme";
import { Product, ProductMatch, SearchResponse, useApp } from "@/src/context/AppContext";

type Section = "search" | "browse";

export default function HomeScreen() {
  const { search, api } = useApp();
  const insets = useSafeAreaInsets();

  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<SearchResponse | null>(null);

  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [browseProducts, setBrowseProducts] = useState<Product[]>([]);
  const [browseLoading, setBrowseLoading] = useState(false);
  const [browseHasMore, setBrowseHasMore] = useState(true);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [categories, setCategories] = useState<string[]>([]);
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const [reasonModal, setReasonModal] = useState<{ visible: boolean; product: Product | null; reason: string }>({
    visible: false,
    product: null,
    reason: "",
  });

  const inputRef = useRef<TextInput>(null);

  useEffect(() => {
    (async () => {
      try {
        const [s, c] = await Promise.all([
          api("/api/search/suggestions"),
          api("/api/categories"),
        ]);
        if (s.ok) setSuggestions((await s.json()).suggestions || []);
        if (c.ok) setCategories((await c.json()).categories || []);
      } catch (e) {
        console.log("init load error", e);
      }
    })();
  }, [api]);

  // Load browse products whenever the active category changes.
  useEffect(() => {
    (async () => {
      setBrowseLoading(true);
      setBrowseProducts([]);
      setBrowseHasMore(true);
      const catQ = activeCategory === "All" ? "" : `&category=${encodeURIComponent(activeCategory)}`;
      try {
        const [p, ct] = await Promise.all([
          api(`/api/products?skip=0&limit=40${catQ}`),
          api(`/api/products/count${catQ ? `?category=${encodeURIComponent(activeCategory)}` : ""}`),
        ]);
        if (p.ok) {
          const items: Product[] = await p.json();
          setBrowseProducts(items);
          setBrowseHasMore(items.length === 40);
        }
        if (ct.ok) {
          const d = await ct.json();
          setTotalCount(d.count || 0);
        }
      } catch (e) {
        console.log("browse load error", e);
      } finally {
        setBrowseLoading(false);
      }
    })();
  }, [activeCategory, api]);

  const loadMore = async () => {
    if (browseLoading || !browseHasMore) return;
    setBrowseLoading(true);
    const catQ = activeCategory === "All" ? "" : `&category=${encodeURIComponent(activeCategory)}`;
    try {
      const r = await api(`/api/products?skip=${browseProducts.length}&limit=40${catQ}`);
      if (r.ok) {
        const items: Product[] = await r.json();
        setBrowseProducts((prev) => [...prev, ...items]);
        setBrowseHasMore(items.length === 40);
      }
    } finally {
      setBrowseLoading(false);
    }
  };

  const runSearch = async (q?: string) => {
    const finalQ = (q ?? query).trim();
    if (!finalQ) return;
    setQuery(finalQ);
    setLoading(true);
    setError(null);
    try {
      const r = await search(finalQ);
      setResult(r);
    } catch (e: any) {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const clearSearch = () => {
    setQuery("");
    setResult(null);
    setError(null);
  };

  const section: Section = result || loading ? "search" : "browse";

  const filteredBrowse = browseProducts;

  const openReason = (match: ProductMatch) =>
    setReasonModal({ visible: true, product: match.product, reason: match.reason });

  const chips = ["All", ...categories];

  return (
    <SafeAreaView edges={["top"]} style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <View style={styles.header}>
          <View style={styles.brandRow}>
            <Ionicons name="sparkles" size={20} color={Colors.brandPrimary} />
            <Text style={styles.brandTitle}>ConverseCart</Text>
          </View>
          <Text style={styles.tagline}>Ask in your own words. We'll find it.</Text>
          <View style={styles.searchBar}>
            <Ionicons name="search" size={18} color={Colors.muted} />
            <TextInput
              ref={inputRef}
              testID="search-input"
              value={query}
              onChangeText={setQuery}
              onSubmitEditing={() => runSearch()}
              placeholder='Try "running shoes under ₹5,000 for beginners"'
              placeholderTextColor={Colors.muted}
              style={styles.searchInput}
              returnKeyType="search"
            />
            {query.length > 0 && (
              <Pressable testID="clear-search-button" onPress={clearSearch} hitSlop={8}>
                <Ionicons name="close-circle" size={18} color={Colors.muted} />
              </Pressable>
            )}
            <Pressable
              testID="submit-search-button"
              onPress={() => runSearch()}
              style={styles.searchButton}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Ionicons name="arrow-up" size={18} color="#fff" />
              )}
            </Pressable>
          </View>
        </View>

        <ScrollView
          contentContainerStyle={{ paddingBottom: Spacing.xxxl + insets.bottom }}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          {section === "search" && (
            <View style={styles.searchSection}>
              {loading && (
                <View style={styles.loadingCard} testID="loading-indicator">
                  <ActivityIndicator size="small" color={Colors.brandPrimary} />
                  <Text style={styles.loadingText}>Understanding your request…</Text>
                </View>
              )}

              {error && (
                <View style={styles.errorCard}>
                  <Ionicons name="warning-outline" size={18} color={Colors.error} />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              )}

              {result && !loading && (
                <>
                  <View style={styles.summaryCard} testID="ai-summary-card">
                    <View style={styles.summaryHeader}>
                      <Ionicons name="sparkles" size={16} color={Colors.brandPrimary} />
                      <Text style={styles.summaryLabel}>AI Assistant</Text>
                    </View>
                    <Text style={styles.summaryText}>{result.summary}</Text>
                    {(result.intent?.max_price || result.intent?.category || result.intent?.audience) && (
                      <View style={styles.intentRow}>
                        {result.intent?.category && (
                          <View style={styles.intentChip}>
                            <Text style={styles.intentChipText}>{result.intent.category}</Text>
                          </View>
                        )}
                        {result.intent?.audience && (
                          <View style={styles.intentChip}>
                            <Text style={styles.intentChipText}>{result.intent.audience}</Text>
                          </View>
                        )}
                        {result.intent?.max_price && (
                          <View style={styles.intentChip}>
                            <Text style={styles.intentChipText}>Under ₹{result.intent.max_price}</Text>
                          </View>
                        )}
                      </View>
                    )}
                  </View>

                  {result.results.length === 0 ? (
                    <View style={styles.emptyResults}>
                      <Ionicons name="search-outline" size={40} color={Colors.muted} />
                      <Text style={styles.emptyResultsText}>
                        No matches. Try rewording, or explore below.
                      </Text>
                    </View>
                  ) : (
                    <View style={styles.grid}>
                      {result.results.map((m) => (
                        <ProductCard
                          key={m.product.id}
                          product={m.product}
                          reason={m.reason}
                          onWhyPress={() => openReason(m)}
                        />
                      ))}
                    </View>
                  )}
                </>
              )}
            </View>
          )}

          {section === "browse" && (
            <View>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Try asking</Text>
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.suggestionsRow}
              >
                {suggestions.map((s, i) => (
                  <Pressable
                    key={i}
                    testID={`suggestion-${i}`}
                    onPress={() => runSearch(s)}
                    style={styles.suggestionChip}
                  >
                    <Ionicons name="sparkles-outline" size={12} color={Colors.brandPrimary} />
                    <Text style={styles.suggestionText} numberOfLines={1}>
                      {s}
                    </Text>
                  </Pressable>
                ))}
              </ScrollView>

              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Browse the store</Text>
                <Text style={styles.sectionCount}>
                  {totalCount.toLocaleString("en-IN")} products
                </Text>
              </View>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.categoryRow}
              >
                {chips.map((c) => {
                  const active = c === activeCategory;
                  return (
                    <Pressable
                      key={c}
                      testID={`category-chip-${c}`}
                      onPress={() => setActiveCategory(c)}
                      style={[styles.categoryChip, active && styles.categoryChipActive]}
                    >
                      <Text style={[styles.categoryChipText, active && styles.categoryChipTextActive]}>
                        {c}
                      </Text>
                    </Pressable>
                  );
                })}
              </ScrollView>

              <View style={styles.grid}>
                {filteredBrowse.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </View>

              {browseHasMore && (
                <View style={styles.loadMoreWrap}>
                  <Pressable
                    testID="load-more-button"
                    onPress={loadMore}
                    style={styles.loadMoreBtn}
                    disabled={browseLoading}
                  >
                    {browseLoading ? (
                      <ActivityIndicator size="small" color={Colors.onSurface} />
                    ) : (
                      <>
                        <Text style={styles.loadMoreText}>Load more</Text>
                        <Ionicons name="arrow-down" size={14} color={Colors.onSurface} />
                      </>
                    )}
                  </Pressable>
                </View>
              )}
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={reasonModal.visible}
        transparent
        animationType="fade"
        onRequestClose={() => setReasonModal({ visible: false, product: null, reason: "" })}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setReasonModal({ visible: false, product: null, reason: "" })}
        >
          <Pressable style={styles.reasonSheet} onPress={() => {}}>
            <View style={styles.reasonHandle} />
            <View style={styles.reasonHeader}>
              <Ionicons name="sparkles" size={16} color={Colors.brandPrimary} />
              <Text style={styles.reasonTitle}>Why this matches</Text>
            </View>
            {reasonModal.product && (
              <Text style={styles.reasonProduct}>{reasonModal.product.title}</Text>
            )}
            <Text style={styles.reasonText}>{reasonModal.reason}</Text>
            <Pressable
              testID="close-reason-modal"
              style={styles.reasonButton}
              onPress={() => setReasonModal({ visible: false, product: null, reason: "" })}
            >
              <Text style={styles.reasonButtonText}>Got it</Text>
            </Pressable>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.surface },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingBottom: Spacing.md,
    backgroundColor: Colors.surface,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  brandRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: Spacing.xs },
  brandTitle: { fontSize: 18, fontWeight: "800", color: Colors.onSurface, letterSpacing: -0.3 },
  tagline: { fontSize: 13, color: Colors.muted, marginTop: 2, marginBottom: Spacing.md },
  searchBar: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.pill,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  searchInput: { flex: 1, fontSize: 14, color: Colors.onSurface, paddingVertical: 8 },
  searchButton: {
    backgroundColor: Colors.brandPrimary,
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
  },

  searchSection: { padding: Spacing.lg },
  loadingCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    backgroundColor: Colors.brandTertiary,
    padding: Spacing.md,
    borderRadius: Radius.md,
    marginBottom: Spacing.md,
  },
  loadingText: { color: Colors.onBrandTertiary, fontSize: 13, fontWeight: "600" },
  errorCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: Spacing.sm,
    backgroundColor: "#FDECEC",
    padding: Spacing.md,
    borderRadius: Radius.md,
    marginBottom: Spacing.md,
  },
  errorText: { color: Colors.error, fontSize: 13, fontWeight: "600" },

  summaryCard: {
    backgroundColor: Colors.brandTertiary,
    padding: Spacing.lg,
    borderRadius: Radius.lg,
    marginBottom: Spacing.lg,
  },
  summaryHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: Spacing.xs },
  summaryLabel: { fontSize: 11, fontWeight: "700", color: Colors.onBrandTertiary, textTransform: "uppercase", letterSpacing: 0.5 },
  summaryText: { fontSize: 15, color: Colors.onBrandTertiary, lineHeight: 21, fontWeight: "500" },
  intentRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: Spacing.md },
  intentChip: {
    backgroundColor: "rgba(255,255,255,0.6)",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: Radius.pill,
  },
  intentChipText: { fontSize: 11, color: Colors.onBrandTertiary, fontWeight: "600" },

  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },

  emptyResults: {
    alignItems: "center",
    padding: Spacing.xxl,
    gap: Spacing.md,
  },
  emptyResultsText: { color: Colors.muted, fontSize: 14, textAlign: "center" },

  sectionHeader: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.sm,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "baseline",
  },
  sectionTitle: { fontSize: 16, fontWeight: "700", color: Colors.onSurface },
  sectionCount: { fontSize: 11, color: Colors.muted, fontWeight: "600" },

  loadMoreWrap: { alignItems: "center", paddingVertical: Spacing.md },
  loadMoreBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.surfaceSecondary,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm,
    borderRadius: Radius.pill,
    minWidth: 140,
    justifyContent: "center",
  },
  loadMoreText: { fontSize: 13, fontWeight: "700", color: Colors.onSurface },

  suggestionsRow: { paddingHorizontal: Spacing.lg, gap: Spacing.sm, paddingVertical: Spacing.xs },
  suggestionChip: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: Colors.surfaceSecondary,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    borderRadius: Radius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
    maxWidth: 260,
    flexShrink: 0,
  },
  suggestionText: { fontSize: 12, color: Colors.onSurface, fontWeight: "500" },

  categoryRow: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    paddingVertical: Spacing.xs,
    height: 56,
    alignItems: "center",
  },
  categoryChip: {
    height: 36,
    paddingHorizontal: 14,
    borderRadius: Radius.pill,
    backgroundColor: Colors.surfaceSecondary,
    borderWidth: 1,
    borderColor: Colors.border,
    justifyContent: "center",
    flexShrink: 0,
  },
  categoryChipActive: {
    backgroundColor: Colors.onSurface,
    borderColor: Colors.onSurface,
  },
  categoryChipText: { fontSize: 12, fontWeight: "600", color: Colors.onSurface },
  categoryChipTextActive: { color: Colors.surface },

  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  reasonSheet: {
    backgroundColor: Colors.surface,
    padding: Spacing.xl,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingBottom: Spacing.xxl,
  },
  reasonHandle: {
    alignSelf: "center",
    width: 44,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.border,
    marginBottom: Spacing.lg,
  },
  reasonHeader: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: Spacing.sm },
  reasonTitle: { fontSize: 12, fontWeight: "700", color: Colors.onSurface, textTransform: "uppercase", letterSpacing: 0.5 },
  reasonProduct: { fontSize: 15, fontWeight: "600", color: Colors.onSurface, marginBottom: Spacing.sm },
  reasonText: { fontSize: 14, color: Colors.onSurface, lineHeight: 20 },
  reasonButton: {
    marginTop: Spacing.xl,
    backgroundColor: Colors.onSurface,
    padding: Spacing.md,
    borderRadius: Radius.pill,
    alignItems: "center",
  },
  reasonButtonText: { color: Colors.surface, fontSize: 14, fontWeight: "700" },
});
