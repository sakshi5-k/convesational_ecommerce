import React, { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";

import { Colors, Radius, Spacing, formatPrice } from "@/src/theme";
import { useApp } from "@/src/context/AppContext";

const METHODS = [
  { id: "cod", label: "Cash on Delivery", icon: "cash-outline" as const },
  { id: "upi", label: "UPI", icon: "phone-portrait-outline" as const },
  { id: "card", label: "Card", icon: "card-outline" as const },
];

export default function CheckoutScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { cart, sessionId, api, refreshCart } = useApp();

  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [method, setMethod] = useState("cod");
  const [placing, setPlacing] = useState(false);
  const [orderId, setOrderId] = useState<string | null>(null);

  const placeOrder = async () => {
    if (!name.trim() || !address.trim()) return;
    setPlacing(true);
    try {
      const r = await api("/api/checkout", {
        method: "POST",
        body: JSON.stringify({
          session_id: sessionId,
          name,
          address,
          payment_method: method,
        }),
      });
      if (r.ok) {
        const d = await r.json();
        setOrderId(d.order_id);
        await refreshCart();
      }
    } finally {
      setPlacing(false);
    }
  };

  if (orderId) {
    return (
      <SafeAreaView style={styles.successContainer}>
        <View style={styles.successCard}>
          <View style={styles.checkCircle}>
            <Ionicons name="checkmark" size={44} color="#fff" />
          </View>
          <Text style={styles.successTitle}>Order Confirmed</Text>
          <Text style={styles.successOrder}>Order ID: {orderId}</Text>
          <Text style={styles.successText}>
            Your order has been placed successfully. This is a mock payment for demo purposes.
          </Text>
          <Pressable
            testID="continue-shopping-button"
            style={styles.doneBtn}
            onPress={() => router.replace("/(tabs)")}
          >
            <Text style={styles.doneBtnText}>Continue Shopping</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={["top"]}>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.backBtn} testID="checkout-close">
          <Ionicons name="close" size={22} color={Colors.onSurface} />
        </Pressable>
        <Text style={styles.title}>Checkout</Text>
        <View style={{ width: 32 }} />
      </View>

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView
          contentContainerStyle={{ padding: Spacing.lg, paddingBottom: 200 }}
          showsVerticalScrollIndicator={false}
        >
          <Text style={styles.sectionLabel}>Delivery Details</Text>
          <View style={styles.field}>
            <Text style={styles.label}>Full Name</Text>
            <TextInput
              testID="checkout-name"
              value={name}
              onChangeText={setName}
              placeholder="Enter your name"
              placeholderTextColor={Colors.muted}
              style={styles.input}
            />
          </View>
          <View style={styles.field}>
            <Text style={styles.label}>Address</Text>
            <TextInput
              testID="checkout-address"
              value={address}
              onChangeText={setAddress}
              placeholder="Street, city, PIN code"
              placeholderTextColor={Colors.muted}
              style={[styles.input, { minHeight: 80, textAlignVertical: "top" }]}
              multiline
            />
          </View>

          <Text style={[styles.sectionLabel, { marginTop: Spacing.xl }]}>Payment Method</Text>
          <View style={{ gap: Spacing.sm }}>
            {METHODS.map((m) => {
              const active = method === m.id;
              return (
                <Pressable
                  key={m.id}
                  testID={`payment-${m.id}`}
                  onPress={() => setMethod(m.id)}
                  style={[styles.methodRow, active && styles.methodRowActive]}
                >
                  <Ionicons name={m.icon} size={20} color={active ? Colors.brandPrimary : Colors.onSurface} />
                  <Text style={[styles.methodText, active && { color: Colors.brandPrimary, fontWeight: "700" }]}>
                    {m.label}
                  </Text>
                  <View style={{ flex: 1 }} />
                  {active && <Ionicons name="checkmark-circle" size={20} color={Colors.brandPrimary} />}
                </Pressable>
              );
            })}
          </View>

          <Text style={[styles.sectionLabel, { marginTop: Spacing.xl }]}>Order Summary</Text>
          {cart?.items.map((line) => (
            <View key={line.product.id} style={styles.summaryLine}>
              <Text style={styles.summaryItem} numberOfLines={1}>
                {line.product.title} × {line.quantity}
              </Text>
              <Text style={styles.summaryVal}>{formatPrice(line.line_total)}</Text>
            </View>
          ))}
          <View style={styles.divider} />
          <View style={styles.summaryLine}>
            <Text style={styles.totalLbl}>Total</Text>
            <Text style={styles.totalVal}>{formatPrice(cart?.subtotal ?? 0)}</Text>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <View style={[styles.stickyBar, { paddingBottom: insets.bottom + Spacing.md }]}>
        <Pressable
          testID="place-order-button"
          style={[
            styles.placeBtn,
            (!name.trim() || !address.trim() || placing) && { opacity: 0.5 },
          ]}
          onPress={placeOrder}
          disabled={!name.trim() || !address.trim() || placing}
        >
          {placing ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <>
              <Ionicons name="lock-closed" size={16} color="#fff" />
              <Text style={styles.placeText}>Place Order · {formatPrice(cart?.subtotal ?? 0)}</Text>
            </>
          )}
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.surface },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  backBtn: { width: 32, height: 32, alignItems: "center", justifyContent: "center" },
  title: { fontSize: 18, fontWeight: "800", color: Colors.onSurface },

  sectionLabel: {
    fontSize: 11,
    fontWeight: "800",
    textTransform: "uppercase",
    letterSpacing: 0.6,
    color: Colors.muted,
    marginBottom: Spacing.sm,
  },
  field: { marginBottom: Spacing.md },
  label: { fontSize: 12, color: Colors.muted, marginBottom: 4 },
  input: {
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    fontSize: 14,
    color: Colors.onSurface,
  },
  methodRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.md,
    padding: Spacing.md,
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  methodRowActive: { borderColor: Colors.brandPrimary, backgroundColor: Colors.brandTertiary },
  methodText: { fontSize: 14, color: Colors.onSurface, fontWeight: "500" },

  summaryLine: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 4,
  },
  summaryItem: { fontSize: 13, color: Colors.onSurface, flex: 1, marginRight: Spacing.md },
  summaryVal: { fontSize: 13, color: Colors.onSurface, fontWeight: "600" },
  divider: { height: 1, backgroundColor: Colors.border, marginVertical: Spacing.sm },
  totalLbl: { fontSize: 15, fontWeight: "800", color: Colors.onSurface },
  totalVal: { fontSize: 18, fontWeight: "800", color: Colors.onSurface },

  stickyBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: Colors.surfaceSecondary,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    padding: Spacing.lg,
  },
  placeBtn: {
    backgroundColor: Colors.onSurface,
    padding: 16,
    borderRadius: Radius.pill,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  placeText: { color: "#fff", fontWeight: "800", fontSize: 14 },

  successContainer: { flex: 1, backgroundColor: Colors.surface, alignItems: "center", justifyContent: "center", padding: Spacing.xl },
  successCard: { alignItems: "center", gap: Spacing.md, maxWidth: 320 },
  checkCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: Colors.success,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: Spacing.md,
  },
  successTitle: { fontSize: 22, fontWeight: "800", color: Colors.onSurface },
  successOrder: { fontSize: 14, color: Colors.muted, fontWeight: "600" },
  successText: { fontSize: 13, color: Colors.muted, textAlign: "center", lineHeight: 19 },
  doneBtn: {
    marginTop: Spacing.lg,
    backgroundColor: Colors.onSurface,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md,
    borderRadius: Radius.pill,
  },
  doneBtnText: { color: "#fff", fontWeight: "700" },
});
