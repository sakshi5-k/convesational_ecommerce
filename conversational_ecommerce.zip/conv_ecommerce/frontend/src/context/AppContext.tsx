import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

const BASE_URL = process.env.EXPO_PUBLIC_BACKEND_URL;

export type Product = {
  id: string;
  title: string;
  brand: string;
  category: string;
  subcategory: string;
  price: number;
  mrp: number;
  rating: number;
  rating_count: number;
  tags: string[];
  features: string[];
  description: string;
  image: string;
  stock: number;
};

export type ProductMatch = { product: Product; reason: string; score: number };

export type SearchResponse = {
  session_id: string;
  query: string;
  summary: string;
  intent: Record<string, any>;
  results: ProductMatch[];
};

export type CartLine = { product: Product; quantity: number; line_total: number };
export type Cart = { session_id: string; items: CartLine[]; subtotal: number; total_items: number };

type Ctx = {
  sessionId: string;
  cart: Cart | null;
  wishlist: Product[];
  refreshCart: () => Promise<void>;
  refreshWishlist: () => Promise<void>;
  addToCart: (productId: string, quantity?: number) => Promise<void>;
  updateCart: (productId: string, quantity: number) => Promise<void>;
  removeFromCart: (productId: string) => Promise<void>;
  toggleWishlist: (productId: string) => Promise<boolean>;
  isInWishlist: (productId: string) => boolean;
  cartItemCount: number;
  wishlistCount: number;
  search: (query: string) => Promise<SearchResponse>;
  api: (path: string, init?: RequestInit) => Promise<Response>;
};

const AppContext = createContext<Ctx | null>(null);

function makeSessionId() {
  return "s_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [sessionId, setSessionId] = useState<string>("");
  const [cart, setCart] = useState<Cart | null>(null);
  const [wishlist, setWishlist] = useState<Product[]>([]);

  useEffect(() => {
    (async () => {
      let sid = await AsyncStorage.getItem("session_id");
      if (!sid) {
        sid = makeSessionId();
        await AsyncStorage.setItem("session_id", sid);
      }
      setSessionId(sid);
    })();
  }, []);

  const api = useCallback(async (path: string, init?: RequestInit) => {
    const url = `${BASE_URL}${path}`;
    const res = await fetch(url, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        ...(init?.headers || {}),
      },
    });
    return res;
  }, []);

  const refreshCart = useCallback(async () => {
    if (!sessionId) return;
    try {
      const r = await api(`/api/cart/${sessionId}`);
      if (r.ok) setCart(await r.json());
    } catch (e) {
      console.log("cart refresh error", e);
    }
  }, [sessionId, api]);

  const refreshWishlist = useCallback(async () => {
    if (!sessionId) return;
    try {
      const r = await api(`/api/wishlist/${sessionId}`);
      if (r.ok) {
        const d = await r.json();
        setWishlist(d.items || []);
      }
    } catch (e) {
      console.log("wishlist refresh error", e);
    }
  }, [sessionId, api]);

  useEffect(() => {
    if (sessionId) {
      refreshCart();
      refreshWishlist();
    }
  }, [sessionId, refreshCart, refreshWishlist]);

  const addToCart = useCallback(
    async (productId: string, quantity = 1) => {
      const r = await api(`/api/cart/add`, {
        method: "POST",
        body: JSON.stringify({ session_id: sessionId, product_id: productId, quantity }),
      });
      if (r.ok) setCart(await r.json());
    },
    [sessionId, api]
  );

  const updateCart = useCallback(
    async (productId: string, quantity: number) => {
      const r = await api(`/api/cart/update`, {
        method: "POST",
        body: JSON.stringify({ session_id: sessionId, product_id: productId, quantity }),
      });
      if (r.ok) setCart(await r.json());
    },
    [sessionId, api]
  );

  const removeFromCart = useCallback(
    async (productId: string) => {
      const r = await api(`/api/cart/remove`, {
        method: "POST",
        body: JSON.stringify({ session_id: sessionId, product_id: productId, quantity: 0 }),
      });
      if (r.ok) setCart(await r.json());
    },
    [sessionId, api]
  );

  const toggleWishlist = useCallback(
    async (productId: string) => {
      const r = await api(`/api/wishlist/toggle`, {
        method: "POST",
        body: JSON.stringify({ session_id: sessionId, product_id: productId }),
      });
      let added = false;
      if (r.ok) {
        const d = await r.json();
        added = !!d.added;
        await refreshWishlist();
      }
      return added;
    },
    [sessionId, api, refreshWishlist]
  );

  const search = useCallback(
    async (query: string) => {
      const r = await api(`/api/search`, {
        method: "POST",
        body: JSON.stringify({ query, session_id: sessionId }),
      });
      if (!r.ok) throw new Error("Search failed");
      return (await r.json()) as SearchResponse;
    },
    [sessionId, api]
  );

  const isInWishlist = useCallback(
    (productId: string) => wishlist.some((p) => p.id === productId),
    [wishlist]
  );

  const value = useMemo<Ctx>(
    () => ({
      sessionId,
      cart,
      wishlist,
      refreshCart,
      refreshWishlist,
      addToCart,
      updateCart,
      removeFromCart,
      toggleWishlist,
      isInWishlist,
      cartItemCount: cart?.total_items ?? 0,
      wishlistCount: wishlist.length,
      search,
      api,
    }),
    [sessionId, cart, wishlist, refreshCart, refreshWishlist, addToCart, updateCart, removeFromCart, toggleWishlist, isInWishlist, search, api]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
