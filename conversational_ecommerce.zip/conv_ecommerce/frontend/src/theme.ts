export const Colors = {
  surface: "#FDFDF9",
  onSurface: "#1C1C1A",
  surfaceSecondary: "#FFFFFF",
  onSurfaceSecondary: "#1C1C1A",
  surfaceTertiary: "#F0F0EA",
  onSurfaceTertiary: "#1C1C1A",
  surfaceInverse: "#1C1C1A",
  onSurfaceInverse: "#FDFDF9",
  brand: "#8A9A5B",
  brandPrimary: "#768A44",
  onBrandPrimary: "#FFFFFF",
  brandSecondary: "#C15B3D",
  onBrandSecondary: "#FFFFFF",
  brandTertiary: "#E6EDD8",
  onBrandTertiary: "#3E4D21",
  success: "#5D7B48",
  onSuccess: "#FFFFFF",
  warning: "#D99C3D",
  onWarning: "#FFFFFF",
  error: "#B33939",
  onError: "#FFFFFF",
  info: "#4A5D4E",
  onInfo: "#FFFFFF",
  border: "#E5E5DF",
  borderStrong: "#CCCCCC",
  divider: "#E5E5DF",
  muted: "#6E6E68",
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  xxxl: 48,
};

export const Radius = {
  sm: 6,
  md: 12,
  lg: 20,
  pill: 999,
};

export const Fonts = {
  regular: "System",
  bold: "System",
};

export function formatPrice(n: number) {
  try {
    return "₹" + n.toLocaleString("en-IN");
  } catch {
    return "₹" + n;
  }
}

export function discountPercent(mrp: number, price: number) {
  if (!mrp || mrp <= price) return 0;
  return Math.round(((mrp - price) / mrp) * 100);
}
