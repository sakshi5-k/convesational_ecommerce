import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { Colors, Radius, Spacing, formatPrice, discountPercent } from "../theme";
import { Product } from "../context/AppContext";
import { useApp } from "../context/AppContext";

type Props = {
  product: Product;
  reason?: string;
  onWhyPress?: () => void;
  compact?: boolean;
};

export default function ProductCard({ product, reason, onWhyPress, compact }: Props) {
  const router = useRouter();
  const { toggleWishlist, isInWishlist } = useApp();
  const wished = isInWishlist(product.id);
  const off = discountPercent(product.mrp, product.price);

  return (
    <Pressable
      testID={`product-card-${product.id}`}
      style={[styles.card, compact && styles.compact]}
      onPress={() => router.push(`/product/${product.id}`)}
    >
      <View style={styles.imageWrap}>
        <Image
          source={{ uri: product.image }}
          style={styles.image}
          contentFit="cover"
          transition={200}
        />
        <Pressable
          testID={`wishlist-toggle-${product.id}`}
          onPress={() => toggleWishlist(product.id)}
          style={styles.heart}
          hitSlop={8}
        >
          <Ionicons
            name={wished ? "heart" : "heart-outline"}
            size={18}
            color={wished ? Colors.brandSecondary : Colors.onSurface}
          />
        </Pressable>
        {off > 0 && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>{off}% OFF</Text>
          </View>
        )}
      </View>
      <View style={styles.body}>
        <Text style={styles.brand} numberOfLines={1}>
          {product.brand}
        </Text>
        <Text style={styles.title} numberOfLines={2}>
          {product.title}
        </Text>
        <View style={styles.priceRow}>
          <Text style={styles.price}>{formatPrice(product.price)}</Text>
          {product.mrp > product.price && (
            <Text style={styles.mrp}>{formatPrice(product.mrp)}</Text>
          )}
        </View>
        <View style={styles.ratingRow}>
          <View style={styles.ratingPill}>
            <Text style={styles.ratingText}>{product.rating.toFixed(1)}</Text>
            <Ionicons name="star" size={10} color="#fff" />
          </View>
          <Text style={styles.ratingCount}>({product.rating_count.toLocaleString("en-IN")})</Text>
        </View>
        {reason ? (
          <Pressable
            testID={`why-badge-${product.id}`}
            onPress={onWhyPress}
            style={styles.whyBadge}
          >
            <Ionicons name="sparkles" size={12} color={Colors.onBrandTertiary} />
            <Text style={styles.whyText} numberOfLines={1}>
              Why this?
            </Text>
          </Pressable>
        ) : null}
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: "48%",
    backgroundColor: Colors.surfaceSecondary,
    borderRadius: Radius.md,
    marginBottom: Spacing.lg,
    overflow: "hidden",
    borderWidth: 1,
    borderColor: Colors.border,
  },
  compact: { width: "100%" },
  imageWrap: {
    width: "100%",
    aspectRatio: 1,
    backgroundColor: Colors.surfaceTertiary,
    position: "relative",
  },
  image: { width: "100%", height: "100%" },
  heart: {
    position: "absolute",
    top: Spacing.sm,
    right: Spacing.sm,
    backgroundColor: "rgba(255,255,255,0.9)",
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  discountBadge: {
    position: "absolute",
    top: Spacing.sm,
    left: Spacing.sm,
    backgroundColor: Colors.brandSecondary,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: Radius.sm,
  },
  discountText: { color: "#fff", fontSize: 10, fontWeight: "700" },
  body: { padding: Spacing.md },
  brand: {
    fontSize: 11,
    color: Colors.muted,
    textTransform: "uppercase",
    letterSpacing: 0.4,
    marginBottom: 2,
  },
  title: {
    fontSize: 13,
    fontWeight: "600",
    color: Colors.onSurface,
    minHeight: 34,
    lineHeight: 17,
  },
  priceRow: { flexDirection: "row", alignItems: "baseline", marginTop: Spacing.xs, gap: 6 },
  price: { fontSize: 15, fontWeight: "700", color: Colors.onSurface },
  mrp: { fontSize: 11, color: Colors.muted, textDecorationLine: "line-through" },
  ratingRow: { flexDirection: "row", alignItems: "center", marginTop: 6, gap: 6 },
  ratingPill: {
    backgroundColor: Colors.success,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: Radius.sm,
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
  },
  ratingText: { color: "#fff", fontSize: 10, fontWeight: "700" },
  ratingCount: { fontSize: 10, color: Colors.muted },
  whyBadge: {
    marginTop: Spacing.sm,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: Colors.brandTertiary,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: Radius.pill,
    alignSelf: "flex-start",
  },
  whyText: { color: Colors.onBrandTertiary, fontSize: 11, fontWeight: "600" },
});
